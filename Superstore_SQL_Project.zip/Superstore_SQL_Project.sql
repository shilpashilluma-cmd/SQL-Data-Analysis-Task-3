
-- Superstore SQL Project

-- 1. Create Table
CREATE TABLE superstore (
    order_id VARCHAR(50),
    customer_name VARCHAR(100),
    category VARCHAR(50),
    region VARCHAR(50),
    sales FLOAT,
    profit FLOAT
);

-- 2. Insert Data
INSERT INTO superstore VALUES
('CA-2016-152156', 'Claire Gute', 'Furniture', 'West', 261.96, 41.91),
('CA-2016-152156', 'Claire Gute', 'Furniture', 'West', 731.94, 219.58),
('CA-2016-138688', 'Darrin Van Huff', 'Office Supplies', 'West', 14.62, 6.87),
('US-2015-108966', 'Sean Miller', 'Technology', 'South', 957.58, 191.52);

-- 3. Select All
SELECT * FROM superstore;

-- 4. Filter by Region
SELECT * FROM superstore
WHERE region = 'West';

-- 5. Order by Sales Descending
SELECT customer_name, sales
FROM superstore
ORDER BY sales DESC;

-- 6. Total Sales by Category
SELECT category, SUM(sales) AS total_sales
FROM superstore
GROUP BY category;

-- 7. Average Profit by Region
SELECT region, AVG(profit) AS avg_profit
FROM superstore
GROUP BY region;

-- 8. Subquery: Sales Greater than Average
SELECT *
FROM superstore
WHERE sales > (SELECT AVG(sales) FROM superstore);
